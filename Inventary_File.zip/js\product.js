// ============================================
// Product Logic & Purchase Flow
// ============================================

let currentProduct = null;

document.addEventListener("DOMContentLoaded", () => {
  renderProducts("All");
  renderHistory();
  setupModal();
});

function renderProducts(filter) {
  const container = document.getElementById("productList");
  container.innerHTML = "";

  // 'products' is global from api.js
  const filtered = filter === "All" ? products : products.filter(p => p.category === filter);

  filtered.forEach(p => {
    const div = document.createElement("div");
    div.className = "card product-card"; // Added product-card for flex alignment
    // Safe check for lat/lon: could be direct props or inside supplier object
    const lat = p.lat || (p.supplier && p.supplier.lat) || "N/A";
    const lon = p.lon || (p.supplier && p.supplier.lon) || "N/A";

    div.innerHTML = `
      <div>
        <span style="font-size:0.8rem; background:#e2e8f0; padding:4px 8px; border-radius:4px; text-transform:uppercase; font-weight:600;">${p.category}</span>
        <h3 style="margin-top:10px; margin-bottom:5px;">${p.name}</h3>
        <p style="font-size:0.85rem; color:#64748b; margin-bottom:10px;">
          📍 Loc: ${lat}, ${lon}
        </p>
      </div>
      <div>
        <div class="price-tag">₹${p.price.toLocaleString()}</div>
        <button class="btn primary full-width" onclick="openPurchaseModal(${p.id})">Buy Now</button>
      </div>
    `;
    container.appendChild(div);
  });
}

function filterCategory(cat) {
  document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("primary"));
  document.querySelectorAll(".filter-btn").forEach(b => {
    if (b.textContent.includes(cat) || (cat === 'All' && b.textContent === 'All')) b.classList.add("primary");
  });
  renderProducts(cat);
}

// ============================================
// Modal Logic
// ============================================

function setupModal() {
  const modal = document.getElementById("purchaseModal");
  // Close on outside click
  window.onclick = (e) => { if (e.target == modal) closePurchaseModal(); }
}

function openPurchaseModal(id) {
  currentProduct = products.find(p => p.id === id);
  if (!currentProduct) return;

  document.getElementById("modalTitle").innerText = `Buy ${currentProduct.name}`;
  document.getElementById("modalPrice").innerText = `Base Price: ₹${currentProduct.price.toLocaleString()}`;
  document.getElementById("purchaseModal").style.display = "flex";
}

function closePurchaseModal() {
  document.getElementById("purchaseModal").style.display = "none";
  document.getElementById("purchaseForm").reset();
  currentProduct = null;
}

function submitOrder(e) {
  e.preventDefault();
  if (!currentProduct) return;

  // Gather Data
  const name = document.getElementById("custName").value;
  const address = document.getElementById("custDetails").value; // Combined Addr/Location
  const qty = parseInt(document.getElementById("custQty").value);
  const gst = document.getElementById("custGst").value;

  // Validation
  if (qty < 12) { alert("Minimum order quantity is 12 units for bulk purchase."); return; }

  const total = currentProduct.price * qty;

  // GST Check
  if (total > 1500000 && !gst) {
    alert(`Order Total: ₹${total.toLocaleString()}\nOrders above 15 Lakhs require a valid GST Number.`);
    return;
  }

  // Create Order Object
  const order = {
    date: new Date().toLocaleDateString(),
    product: currentProduct.name,
    qty: qty,
    total: total,
    customer: name,
    address: address,
    gst: gst || "N/A"
  };

  // Mock API Call
  apiPlaceOrder(order);

  alert(`Order Placed Successfully!\nTotal: ₹${total.toLocaleString()}\nCheck Order History.`);
  closePurchaseModal();
  renderHistory();
}

// ============================================
// History Logic
// ============================================

function renderHistory() {
  const list = document.getElementById("orderHistory");
  if (!list) return;

  list.innerHTML = "";
  const history = apiGetHistory().reverse(); // Show newest first

  if (history.length === 0) {
    list.innerHTML = "<p>No orders yet.</p>";
    return;
  }

  history.forEach(o => {
    const item = document.createElement("div");
    item.className = "card";
    item.style.padding = "1rem";
    item.innerHTML = `
      <div style="display:flex; justify-content:space-between;">
        <strong>${o.product}</strong>
        <span>₹${o.total.toLocaleString()}</span>
      </div>
      <div style="font-size:0.9rem; color:#666; margin-top:5px;">
        ${o.date} • Qty: ${o.qty} • GST: ${o.gst}
      </div>
    `;
    list.appendChild(item);
  });
}