// =========================================================
// IMS API Module
// Handles Mock Data, Authentication, and Simulated Backend
// =========================================================

const users = JSON.parse(localStorage.getItem("ims_users")) || {};
const orders = JSON.parse(localStorage.getItem("ims_orders")) || [];

/**
 * Validate Login Credentials
 * @param {string} user 
 * @param {string} pass 
 * @returns {boolean}
 */
function apiLogin(user, pass) {
  return users[user] && users[user] === pass;
}

/**
 * Register New User
 * @param {string} user 
 * @param {string} pass 
 * @returns {boolean}
 */
function apiCreateUser(user, pass) {
  if (users[user]) return false;
  users[user] = pass;
  localStorage.setItem("ims_users", JSON.stringify(users));
  return true;
}

/**
 * Save Order to History
 * @param {object} orderDetails 
 */
function apiPlaceOrder(orderDetails) {
  orders.push(orderDetails);
  localStorage.setItem("ims_orders", JSON.stringify(orders));
  console.log("Order Saved:", orderDetails);
}

/**
 * Get Order History
 * @returns {Array}
 */
function apiGetHistory() {
  return orders;
}

// =========================================================
// MOCK DATA: 50+ Products
// Categories: Mobiles, Laptops, Accessories
// =========================================================

// =========================================================
const admins = JSON.parse(localStorage.getItem("ims_admins")) || {};

/**
 * Validate Admin Login
 */
function apiAdminLogin(user, pass) {
  return admins[user] && admins[user] === pass;
}

/**
 * Create Admin
 */
function apiAdminCreate(user, pass) {
  if (admins[user]) return false;
  admins[user] = pass;
  localStorage.setItem("ims_admins", JSON.stringify(admins));
  return true;
}

/**
 * Add New Product to Inventory
 */
function apiAddProduct(product) {
  // Assign ID
  const newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
  product.id = newId;
  products.push(product);

  // Persist
  localStorage.setItem("ims_products", JSON.stringify(products));
  return true;
}

// =========================================================
// MOCK DATA: Products (Load from LS if available)
// =========================================================

let products = JSON.parse(localStorage.getItem("ims_products"));

// Helper to generate random coords around India
function getMockLoc() {
  return { lat: (19 + Math.random() * 10).toFixed(4), lon: (72 + Math.random() * 10).toFixed(4) };
}

if (!products || products.length === 0) {
  products = [
    // Mobiles
    { id: 1, category: "Mobile", name: "Samsung Galaxy S23", price: 72000, ...getMockLoc() },
    { id: 2, category: "Mobile", name: "Apple iPhone 15", price: 89000, ...getMockLoc() },
    { id: 3, category: "Mobile", name: "OnePlus 12R", price: 56000, ...getMockLoc() },
    { id: 4, category: "Mobile", name: "Google Pixel 8", price: 75999, ...getMockLoc() },
    { id: 5, category: "Mobile", name: "Xiaomi 14", price: 69999, ...getMockLoc() },
    { id: 6, category: "Mobile", name: "Samsung Galaxy Z Flip5", price: 99999, ...getMockLoc() },
    { id: 7, category: "Mobile", name: "iPhone 14 Plus", price: 79900, ...getMockLoc() },
    { id: 8, category: "Mobile", name: "Nothing Phone (2)", price: 44999, ...getMockLoc() },
    { id: 9, category: "Mobile", name: "Realme GT 2 Pro", price: 39999, ...getMockLoc() },
    { id: 10, category: "Mobile", name: "Vivo X90 Pro", price: 84999, ...getMockLoc() },
    { id: 11, category: "Mobile", name: "Oppo Reno 10 Pro", price: 54999, ...getMockLoc() },
    { id: 12, category: "Mobile", name: "Samsung S21 FE", price: 34999, ...getMockLoc() },
    { id: 13, category: "Mobile", name: "iPhone 13", price: 59900, ...getMockLoc() },
    { id: 14, category: "Mobile", name: "Poco F5", price: 29999, ...getMockLoc() },
    { id: 15, category: "Mobile", name: "Motorola Edge 40", price: 29999, ...getMockLoc() },
    { id: 16, category: "Mobile", name: "iQOO Neo 7", price: 33999, ...getMockLoc() },
    { id: 17, category: "Mobile", name: "Asus ROG Phone 7", price: 74999, ...getMockLoc() },
    { id: 18, category: "Mobile", name: "Samsung Galaxy M34", price: 18999, ...getMockLoc() },
    { id: 19, category: "Mobile", name: "Redmi Note 13 Pro", price: 25999, ...getMockLoc() },
    { id: 20, category: "Mobile", name: "Lava Agni 2", price: 21999, ...getMockLoc() },

    // Laptops
    { id: 21, category: "Laptop", name: "MacBook Air M2", price: 114900, ...getMockLoc() },
    { id: 22, category: "Laptop", name: "Dell XPS 13", price: 134900, ...getMockLoc() },
    { id: 23, category: "Laptop", name: "HP Spectre x360", price: 145000, ...getMockLoc() },
    { id: 24, category: "Laptop", name: "Lenovo ThinkPad X1", price: 160000, ...getMockLoc() },
    { id: 25, category: "Laptop", name: "Asus ZenBook 14", price: 89990, ...getMockLoc() },
    { id: 26, category: "Laptop", name: "Acer Swift 5", price: 74999, ...getMockLoc() },
    { id: 27, category: "Laptop", name: "Microsoft Surface 5", price: 105999, ...getMockLoc() },
    { id: 28, category: "Laptop", name: "MSI Raider GE78", price: 289990, ...getMockLoc() },
    { id: 29, category: "Laptop", name: "Razer Blade 15", price: 249999, ...getMockLoc() },
    { id: 30, category: "Laptop", name: "Samsung Galaxy Book3", price: 94990, ...getMockLoc() },
    { id: 31, category: "Laptop", name: "MacBook Pro 16", price: 249900, ...getMockLoc() },
    { id: 32, category: "Laptop", name: "Dell Inspiron 15", price: 54990, ...getMockLoc() },
    { id: 33, category: "Laptop", name: "HP Pavilion 15", price: 62990, ...getMockLoc() },
    { id: 34, category: "Laptop", name: "Lenovo Yoga 9i", price: 174990, ...getMockLoc() },
    { id: 35, category: "Laptop", name: "Asus Vivobook 16", price: 49990, ...getMockLoc() },

    // Accessories
    { id: 36, category: "Accessory", name: "AirPods Pro 2", price: 24900, ...getMockLoc() },
    { id: 37, category: "Accessory", name: "Galaxy Buds 2 Pro", price: 16990, ...getMockLoc() },
    { id: 38, category: "Accessory", name: "Sony WH-1000XM5", price: 29990, ...getMockLoc() },
    { id: 39, category: "Accessory", name: "Logitech MX Master 3S", price: 9995, ...getMockLoc() },
    { id: 40, category: "Accessory", name: "Keychron K2 V2", price: 8499, ...getMockLoc() },
    { id: 41, category: "Accessory", name: "Dell 27 4K Monitor", price: 45999, ...getMockLoc() },
    { id: 42, category: "Accessory", name: "Samsung T7 SSD 1TB", price: 8999, ...getMockLoc() },
    { id: 43, category: "Accessory", name: "Apple Watch Series 9", price: 41900, ...getMockLoc() },
    { id: 44, category: "Accessory", name: "Fitbit Charge 6", price: 14999, ...getMockLoc() },
    { id: 45, category: "Accessory", name: "Anker 737 PowerBank", price: 12999, ...getMockLoc() },
    { id: 46, category: "Accessory", name: "JBL Flip 6", price: 9999, ...getMockLoc() },
    { id: 47, category: "Accessory", name: "GoPro Hero 11", price: 34990, ...getMockLoc() },
    { id: 48, category: "Accessory", name: "DJI Mini 3 Pro", price: 79990, ...getMockLoc() },
    { id: 49, category: "Accessory", name: "Kindle Paperwhite", price: 13999, ...getMockLoc() },
    { id: 50, category: "Accessory", name: "Google Nest Hub", price: 7999, ...getMockLoc() },
  ];
  // Init LS
  localStorage.setItem("ims_products", JSON.stringify(products));
}

// =========================================================
// MOCK DATA: 30+ Stores
// Locations: Major Cities across India
// =========================================================

const stores = [
  { name: "Reliance Digital - Mumbai", lat: 19.0760, lon: 72.8777 },
  { name: "Croma - Delhi", lat: 28.6139, lon: 77.2090 },
  { name: "Vijay Sales - Bangalore", lat: 12.9716, lon: 77.5946 },
  { name: "Reliance Digital - Hyderabad", lat: 17.3850, lon: 78.4867 },
  { name: "Croma - Chennai", lat: 13.0827, lon: 80.2707 },
  { name: "Vijay Sales - Ahmedabad", lat: 23.0225, lon: 72.5714 },
  { name: "Reliance Digital - Kolkata", lat: 22.5726, lon: 88.3639 },
  { name: "Croma - Pune", lat: 18.5204, lon: 73.8567 },
  { name: "Vijay Sales - Jaipur", lat: 26.9124, lon: 75.7873 },
  { name: "Reliance Digital - Surat", lat: 21.1702, lon: 72.8311 },
  { name: "Croma - Lucknow", lat: 26.8467, lon: 80.9462 },
  { name: "Vijay Sales - Kanpur", lat: 26.4499, lon: 80.3319 },
  { name: "Reliance Digital - Nagpur", lat: 21.1458, lon: 79.0882 },
  { name: "Croma - Indore", lat: 22.7196, lon: 75.8577 },
  { name: "Vijay Sales - Thane", lat: 19.2183, lon: 72.9781 },
  { name: "Reliance Digital - Bhopal", lat: 23.2599, lon: 77.4126 },
  { name: "Croma - Visakhapatnam", lat: 17.6868, lon: 83.2185 },
  { name: "Vijay Sales - Pimpri-Chinchwad", lat: 18.6298, lon: 73.7997 },
  { name: "Reliance Digital - Patna", lat: 25.5941, lon: 85.1376 },
  { name: "Croma - Vadodara", lat: 22.3072, lon: 73.1812 },
  { name: "Vijay Sales - Ghaziabad", lat: 28.6692, lon: 77.4538 },
  { name: "Reliance Digital - Ludhiana", lat: 30.9010, lon: 75.8573 },
  { name: "Croma - Agra", lat: 27.1767, lon: 78.0081 },
  { name: "Vijay Sales - Nashik", lat: 19.9975, lon: 73.7898 },
  { name: "Reliance Digital - Faridabad", lat: 28.4089, lon: 77.3178 },
  { name: "Croma - Meerut", lat: 28.9845, lon: 77.7064 },
  { name: "Vijay Sales - Rajkot", lat: 22.3039, lon: 70.8022 },
  { name: "Reliance Digital - Kalyan-Dombivli", lat: 19.2183, lon: 73.1331 },
  { name: "Croma - Vasai-Virar", lat: 19.3919, lon: 72.8397 },
  { name: "Vijay Sales - Varanasi", lat: 25.3176, lon: 82.9739 },
  { name: "Reliance Digital - Srinagar", lat: 34.0837, lon: 74.7973 },
  { name: "Croma - Aurangabad", lat: 19.8762, lon: 75.3433 },
  { name: "Vijay Sales - Dhanbad", lat: 23.7957, lon: 86.4304 },
  { name: "Reliance Digital - Amritsar", lat: 31.6340, lon: 74.8723 }
];
